username='admin'
password='maxianglin'
assert username == 'admin' and password == 'admin'
