def arrayList (obj,index):
    return obj[index]

userList=['0001','0002','0003','0004']
print arrayList(userList,4)
    