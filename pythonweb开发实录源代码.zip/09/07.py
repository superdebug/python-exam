﻿username='admin'
password='maxianglin'
assert username == 'admin' and password == 'admin','密码错误！'