try:
    b=3
    a=b=c
    print a
    print b
    print c
except Exception,e:
    print e
