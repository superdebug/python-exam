from Django_Pro.Users.models import Users
Users.objects.create(id = 1, username = 'maxianglin' , password = 'maxianglin',realname = '������',sex='Ů',email = 'maxianglin@mxl.com')
Users.objects.create(id = 2, username = 'wanglili' , password = 'wanglili',realname = '������',sex='Ů',email = 'wanglili@wll.com')
Users.objects.create(id = 3, username = 'guoli' , password = 'guoli',realname = '����',sex='��',email = 'guoli@gl.com')
