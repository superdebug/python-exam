from django.contrib import admin
from Django_Pro.Users.models import Users
admin.site.register(Users)