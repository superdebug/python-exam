import urllib
urllib.urlretrieve('http://www.itzcn.com','D:\\python_webpage.html')
