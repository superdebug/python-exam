import wx
print wx.version()
