chengji={'dcy':95,
'admin':90,
'happy':100,
'apple':50,
'sorry':60,
'yyyy':62,
'dream':67,
'jieji':80,
'thowe':75,
'zone':60,
'hao':89}
for key in chengji:
	print key,'�ĳɼ��ǣ�',chengji[key]
