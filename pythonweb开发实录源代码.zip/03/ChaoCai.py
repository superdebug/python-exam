﻿
initXQ='洗菜切菜等'
initJR='加热炒锅，锅干后，导入适量的油'
hotting='用旺火翻炒，直到将菜炒热'
tiaoing='放入盐和味精等调料拌匀'
ts=6

if initXQ=='':
	print '洗菜切菜等'
elif initJR=='':
	print '加热炒锅，锅干后，导入适量的油'
elif hotting=='':
	print '用旺火翻炒，直到将菜炒热'
elif tiaoing=='':
	print '放入盐和味精等调料拌匀'
if ts<5:
	print '放了6勺盐有点淡，再放一点盐'
else:
	print '将菜倒入盘中，端到客厅'
	
	
	
