def operat (x , y):
    return x*y

print reduce(operat , (1,2,3,4,5,6))
print reduce(operat , (7,8,9) , 5)


    