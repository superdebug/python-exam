﻿import max
a=raw_input('请输入第一个数字：')
b=raw_input('请输入第二个数字：')
max.max(a,b)
