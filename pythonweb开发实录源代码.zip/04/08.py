num = 5
def myFun ():
    global num
    num = num + 1
    return num
myFun()
    