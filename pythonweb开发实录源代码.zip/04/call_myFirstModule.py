﻿# 调用自定义模块的类和函数
import myFirstModule

myFirstModule.myFun1()
myFirstModule.myFun2()
myclass=myFirstModule.MyClass()
myclass.myClassFun()