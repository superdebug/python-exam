def filter_fun(arrays):
    if(arrays=='admin'):
        return arrays
print filter(filter_fun,('admin','admin','maxianglin','wanglili'))
