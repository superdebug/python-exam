﻿class MyClass:
    '字符串'
    def printHello ():
        'print Hello World'
        print 'Hello World'
print MyClass.__doc__
print MyClass.printHello.__doc__
        
    