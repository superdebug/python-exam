﻿def addUser (username , realname , addres = '河南省郑州市'):
    if(username != '') and (username != None):
        print '添加成功！'
    else:
        print '添加失败！'
addUser(username ='admin' , realname='小强')
