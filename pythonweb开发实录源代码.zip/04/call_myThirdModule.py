import myThirdModule
print __doc__