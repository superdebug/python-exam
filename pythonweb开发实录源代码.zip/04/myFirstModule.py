﻿# 自定义模块
def myFun1 ():
    print 'myFirstModule myFun1()'

def myFun2 ():
    print 'myFirstModule myFun2()'

class MyClass:
    def myClassFun (self):
        print 'myFirstModule MyClass myClassFun()'
        
    
    
    