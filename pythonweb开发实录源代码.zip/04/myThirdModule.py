﻿if __name__ == '__main__':
    print 'myThirdModule作为主程序'
else:
    print 'myThirdModule被另一个模块调用'
