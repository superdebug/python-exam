def max(x,y):
    if x>y:
        print x
    else:
        print y
