class MyClass:
    def myFun ():
        num=12
        print 'myFun num='+str(num)
    def myFun2 ():
        num=num+1
        print 'myFun2 num='+str(num)
num*=10
print 'mMyClass num='+str(num)
        
  
