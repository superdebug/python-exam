﻿_proName='联想笔记本'
print _proName