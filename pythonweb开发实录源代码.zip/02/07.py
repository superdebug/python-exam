_num = 12
def myFun ():
    num = _num+1
    print 'myFun num='+str(num)
myFun()
   