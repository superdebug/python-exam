print 9 > 6
print 2 >= 2
print 9 == 9
print 2!=2
print 6<>9
 
    