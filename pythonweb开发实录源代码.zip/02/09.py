print 2 < 3 and  4 < 5 
print 2 > 3 or 4 > 5
print not ( 2 < 3 and  4 < 5)

