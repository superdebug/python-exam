class MyClass:
    def MyFirstFun (self):
        print 'MyFirstFun()'
    def MySecondFun (self):
        print 'MySecondFun()'
if __name__ == "__main__":
    myclass = MyClass()
    myclass.MyFirstFun()
    myclass.MySecondFun()

    #Filename:pythonModule.py

    
        

        
    