print "my name is MaXiangLin"
print "my name is MaXiangLin";
x=1 y=2 z=3