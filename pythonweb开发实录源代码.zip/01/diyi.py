﻿name = raw_input("你叫什么名字：")
print "嗨，我的名字叫"+name
