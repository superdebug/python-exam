if os.path.isfile('.pythonrc.py'): execfile('.pythonrc.py')
