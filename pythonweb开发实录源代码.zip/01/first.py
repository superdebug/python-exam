x = int(raw_input("Please enter an integer: "))
if x < 0:
 print 'this number < 0'
if x > 0:
    print "this number >0"
