userTuple = ('0001'  , '0002' , '0003' , '0004' , '0005' , '0006')
new_userTupele=(userTuple , '0007' , '0008')
print new_userTupele
