userList = ['0001' , '0004' , '0006' , '0002' , '0005' , '0003']
userList.sort(reverse=True)
print userList