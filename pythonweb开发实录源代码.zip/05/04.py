﻿userList = ['0001' , '0002' , '0003' , '0004' , '0005']
print '初始化的userList列表为：'+str(userList)
#userList.remove('0003')
del userList[1]
print '删除第2个元素后的userList列表为：'+str(userList)