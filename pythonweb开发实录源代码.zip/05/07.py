numbers = [0,6]
numbers[1:1]=[1,2,3,4,5]
print numbers