userDic={'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
#for key in userDic:
    #print 'userDic[%s]='% key,userDic[key]
print userDic.items()
    
