userStr='maxianglin'
userTuple=('maxianglin','wanglili','wangjunchao')
userList=['maxianglin','wanglili','wangjunchao']
print userStr[0]
print userStr[-2]
print userTuple[-2]
print userList[2]