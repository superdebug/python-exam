﻿userTuple = ('0001'  , '0002' , '0003' , '0004' , '0005' , '0006')
print '元组中的第3个元素为：',userTuple[2]
print '元组中倒数第3个元素为：',userTuple[-3]
print '元组中第3个元素到倒数第2个元素组成的元组为：',userTuple[2:-1]