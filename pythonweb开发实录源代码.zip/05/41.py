userIdStr='0001'*6
print userIdStr
userIdList=['0001']*5
print userIdList