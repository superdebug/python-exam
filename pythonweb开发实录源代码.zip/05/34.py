source_userDic= {'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
print {}.fromkeys(['0001','0002'])
print source_userDic.fromkeys(['0001','0002'])
print source_userDic.fromkeys(['0001','0002'],'maxianglin')
source_userDic['0003']
