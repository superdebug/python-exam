﻿userDic={'name':'maxianglin','age':23,'sex':'female'}
print '调用clear()方法之前：',userDic
userDic.clear()
print '调用clear()方法之后：',userDic