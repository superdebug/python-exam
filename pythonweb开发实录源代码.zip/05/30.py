userDic={'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
for (key , value) in userDic.items():
    print 'userDic[%s]='% key , value
    