userTuple = ('0001' , '0002' , '0003' , '0004' , '0005' , '0006')
for item in range(len(userTuple)):
    print userTuple[item]

    