userTuple = ('0001' , '0002' , '0003')
stu1 , stu2 , stu3 = userTuple
print stu1
print stu2
print stu3