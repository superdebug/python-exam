userList = ['0001' , '0002' , '0003' , '0004' , '0005' , '0006']
subUser1= userList[2:5]
subUser2= userList[-3:-1]
subUser3= userList[0:-2]
print subUser1
print subUser2
print subUser3
