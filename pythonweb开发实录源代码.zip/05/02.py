﻿userList = ['0001' , '0002' , '0006' , '0004' , '0005']
print '初始化的userList列表为：'+str(userList)
userList[2] = '0003'
print '更新后的userList列表为：'+str(userList)