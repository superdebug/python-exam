userTuple1 = ('0001' , '0002' , '0003')
userTuple2 = ('0004' , '0005' , '0006')
userTuple=(userTuple1 , userTuple2)
print userTuple
print 'userTuple[1][0]=',userTuple[1][0]
print 'userTuple[1][2]=',userTuple[1][2]