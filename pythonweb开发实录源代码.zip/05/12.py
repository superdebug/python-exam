﻿userList = ['0001' , '0002' , '0003' , '0004' , '0005' , '0006']
print '元素0002对应的索引值为：',userList.index('0002')
print '0002' in userList