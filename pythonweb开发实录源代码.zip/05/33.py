﻿source_userDic= {'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
target_userDic=source_userDic.copy()
print '修改之前的目标字典target_userDic=',target_userDic
target_userDic['0002'] = 'zhangfang'
print '原字典source_userDic=',source_userDic
print '修改之后的目标字典target_userDic=',target_userDic