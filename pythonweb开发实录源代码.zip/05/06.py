userList = list('Python')
userList[1:] = list('rite')
print userList