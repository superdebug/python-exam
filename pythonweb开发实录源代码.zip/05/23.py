userTuple1 = ('0001' , '0002' , '0003')
userTuple2 = ('0004' , '0005' , '0006')
userTuple=(userTuple1 , userTuple2)
for item in map(None , userTuple):
    for i in item:
        print i
      
   
    