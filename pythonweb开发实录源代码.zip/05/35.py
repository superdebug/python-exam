userDic= {'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
#print userDic.get('0002')
#print userDic.get('0004','zhanghui')
#print userDic['0004']
print userDic.has_key('0004')
print userDic.has_key('0002')
