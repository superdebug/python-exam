userDic= {'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
print userDic.popitem()
print userDic.popitem()
print userDic
