userDic = dict(name='maxianglin',age=24,sex='0')
print userDic