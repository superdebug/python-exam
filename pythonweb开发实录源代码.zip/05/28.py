#userDic={'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
#del(userDic['0002'])
#print userDic

userDic={'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
#print userDic.pop('0002')

#del userDic['0002']
#print userDic
print userDic['0003']