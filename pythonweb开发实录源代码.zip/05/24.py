﻿userDic = [(2,'maxianglin'),(1,'wanglili'),(3,'malinlin')]
dic_userDic = dict(userDic)
print dic_userDic