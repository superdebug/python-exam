userDic= {'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
newDic={'0004':'zhangfang'}
userDic.update(newDic)
print userDic