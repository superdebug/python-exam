userList = ['0001' , '0004' , '0006' , '0002' , '0005' , '0003']
userList.reverse()
print userList