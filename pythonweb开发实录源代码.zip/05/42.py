﻿fruitList=['apple','banana','orange','tomato']
fruit='orange'
if fruit in fruitList:
    print 'orange已经存在'


