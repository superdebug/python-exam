userDic={'0001':'maxianglin','0002':'wanglili','0003':'malinlin'}
userDic.setdefault('0004','zhuhongtao')
print userDic
userDic.setdefault('0001','zhangfang')
print userDic